import { Users, Star, Calendar, Palette, Music, Mountain } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const Offerings = () => {
  const offerings = [
    {
      icon: Users,
      title: "Beginner Classes",
      description: "Embark on your Kathak journey with our beginner classes, designed to introduce you to the foundational footwork, hand gestures, and expressions that form the essence of Kathak."
    },
    {
      icon: Star,
      title: "Advanced Classes",
      description: "Elevate your expertise with our advanced workshops, where you will unravel intricate compositions and delve into the depths of Kathak's emotive storytelling through rhythmic sequences."
    },
    {
      icon: Calendar,
      title: "Private Sessions",
      description: "Experience personalized guidance and mentorship through our private sessions, tailored to nurture your individual strengths and refine your Kathak prowess."
    },
    {
      icon: Palette,
      title: "Choreography Design",
      description: "Let us choreograph captivating Kathak performances for you, intricately woven to showcase your artistry and captivate audiences with the timeless allure of Kathak."
    },
    {
      icon: Music,
      title: "Dance Events",
      description: "Partake in our immersive Kathak dance events, where the community unites to celebrate the opulence and grace of Kathak, fostering a vibrant and supportive environment for all enthusiasts."
    },
    {
      icon: Mountain,
      title: "Dance Retreats",
      description: "Embark on a transformative Kathak retreat with us, where every step resonates with the heritage and ethos of Kathak, surrounded by connoisseurs and expert mentors guiding your journey."
    }
  ];

  return (
    <section className="py-20 bg-warm-cream">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-deep-brown mb-6">
            Our Offerings
          </h2>
          <div className="w-24 h-1 bg-gradient-golden mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {offerings.map((offering, index) => (
            <Card 
              key={index} 
              className="group hover:shadow-warm hover:scale-105 transition-all duration-500 bg-card border-bronze/20 animate-fade-in"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              <CardHeader className="text-center">
                <div className="mx-auto mb-4 p-3 bg-gradient-golden rounded-full w-16 h-16 flex items-center justify-center group-hover:animate-golden-glow">
                  <offering.icon className="h-8 w-8 text-deep-brown" />
                </div>
                <CardTitle className="text-xl font-bold text-deep-brown">
                  {offering.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-muted-foreground leading-relaxed">
                  {offering.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Offerings;