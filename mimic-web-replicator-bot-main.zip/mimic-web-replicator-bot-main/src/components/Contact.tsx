import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Sparkles, Phone, Mail, MapPin } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const Contact = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    phone: '',
    age: '',
    email: '',
    course: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast({
      title: "Registration Submitted!",
      description: "We'll contact you soon to discuss your Kathak journey.",
    });
    setFormData({
      firstName: '',
      lastName: '',
      phone: '',
      age: '',
      email: '',
      course: ''
    });
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <section id="contact" className="py-20 bg-deep-brown">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Info */}
          <div className="space-y-8">
            <div className="flex items-center space-x-3">
              <Sparkles className="h-10 w-10 text-golden" />
              <h2 className="text-4xl font-bold text-warm-cream">KATHAK</h2>
            </div>

            <div className="space-y-6 text-warm-cream">
              <div className="flex items-start space-x-4">
                <Phone className="h-6 w-6 text-golden mt-1" />
                <div>
                  <p className="font-semibold">Phone</p>
                  <p className="text-warm-cream/80">+91 8168959267</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <Mail className="h-6 w-6 text-golden mt-1" />
                <div>
                  <p className="font-semibold">Email</p>
                  <p className="text-warm-cream/80">vishwaraj.joshi@gmail.com</p>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <MapPin className="h-6 w-6 text-golden mt-1" />
                <div>
                  <p className="font-semibold">Address</p>
                  <p className="text-warm-cream/80">
                    500 Terry Francine St.<br />
                    San Francisco, CA 94158
                  </p>
                </div>
              </div>
            </div>

            <div className="space-y-4 text-sm text-warm-cream/60">
              <p>Privacy Policy</p>
              <p>Accessibility Statement</p>
              <p>Terms & Conditions</p>
              <p>Refund Policy</p>
            </div>
          </div>

          {/* Contact Form */}
          <Card className="bg-card border-golden/20">
            <CardHeader>
              <CardTitle className="text-2xl font-bold text-deep-brown text-center">
                ENTER YOUR DETAILS :-
              </CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First name</Label>
                    <Input
                      id="firstName"
                      value={formData.firstName}
                      onChange={(e) => handleInputChange('firstName', e.target.value)}
                      className="border-bronze/30 focus:border-golden"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last name</Label>
                    <Input
                      id="lastName"
                      value={formData.lastName}
                      onChange={(e) => handleInputChange('lastName', e.target.value)}
                      className="border-bronze/30 focus:border-golden"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <div className="flex">
                    <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-bronze/30 bg-muted text-sm">
                      🇮🇳 +91
                    </span>
                    <Input
                      id="phone"
                      type="tel"
                      value={formData.phone}
                      onChange={(e) => handleInputChange('phone', e.target.value)}
                      className="rounded-l-none border-bronze/30 focus:border-golden"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="age">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    value={formData.age}
                    onChange={(e) => handleInputChange('age', e.target.value)}
                    className="border-bronze/30 focus:border-golden"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleInputChange('email', e.target.value)}
                    className="border-bronze/30 focus:border-golden"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="course">Which course do you want to join?</Label>
                  <Select value={formData.course} onValueChange={(value) => handleInputChange('course', value)}>
                    <SelectTrigger className="border-bronze/30 focus:border-golden">
                      <SelectValue placeholder="Select a course" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="beginner">Beginner Classes</SelectItem>
                      <SelectItem value="advanced">Advanced Classes</SelectItem>
                      <SelectItem value="private">Private Sessions</SelectItem>
                      <SelectItem value="choreography">Choreography Design</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button 
                  type="submit"
                  className="w-full bg-gradient-golden hover:shadow-golden text-deep-brown font-semibold py-3 rounded-full transition-all duration-300 hover:scale-105"
                >
                  Submit
                </Button>
              </form>
            </CardContent>
          </Card>
        </div>

        <div className="text-center mt-16 text-warm-cream/60 text-sm">
          - BY PRAYAG SINGH THAKUR - 2035
        </div>
      </div>
    </section>
  );
};

export default Contact;