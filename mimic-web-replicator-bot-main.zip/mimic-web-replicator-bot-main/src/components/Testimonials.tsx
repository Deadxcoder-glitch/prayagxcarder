import { Card, CardContent } from '@/components/ui/card';
import { Quote } from 'lucide-react';

const Testimonials = () => {
  const testimonials = [
    {
      quote: "I have been captivated by the sheer elegance and storytelling in Kathak. The workshops at Kathak Classes have been a transformative experience, unraveling the poetic essence of this classical dance form.",
      author: "Rajendra - Beginner Enthusiast"
    },
    {
      quote: "The immersive atmosphere and dedication to tradition at Kathak Workshop have enriched my understanding of Kathak. I have found a deeper connection with the art and a supportive community that feels like home.",
      author: "Ananya - Advanced Learner"
    },
    {
      quote: "Kathak Classes has not only honed my skills but also nurtured my soul. The guidance and camaraderie here have instilled a profound sense of artistry and cultural appreciation in my Kathak journey.",
      author: "Rohini - Professional Kathak Artist"
    }
  ];

  return (
    <section className="py-20 bg-warm-cream relative overflow-hidden">
      {/* Decorative Wave at Top */}
      <div className="absolute top-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" fill="none" className="w-full h-20">
          <path d="M0,0 L0,60 Q300,120 600,60 T1200,60 L1200,0 Z" fill="hsl(var(--deep-brown))" />
        </svg>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-deep-brown mb-6">
            Student Reviews
          </h2>
          <div className="w-24 h-1 bg-gradient-golden mx-auto rounded-full"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <Card 
              key={index}
              className="group hover:scale-105 transition-all duration-500 bg-card border-bronze/20 relative animate-fade-in"
              style={{ animationDelay: `${index * 0.2}s` }}
            >
              <CardContent className="p-6">
                <Quote className="h-8 w-8 text-golden mb-4 opacity-60" />
                <blockquote className="text-muted-foreground italic leading-relaxed mb-6">
                  "{testimonial.quote}"
                </blockquote>
                <footer className="text-sm font-semibold text-deep-brown">
                  {testimonial.author}
                </footer>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      {/* Decorative Wave at Bottom */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" fill="none" className="w-full h-20">
          <path d="M0,120 L0,60 Q300,0 600,60 T1200,60 L1200,120 Z" fill="hsl(var(--deep-brown))" />
        </svg>
      </div>
    </section>
  );
};

export default Testimonials;