import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Clock, IndianRupee } from 'lucide-react';
import groupDancers from '@/assets/group-dancers.jpg';
import soloDancer from '@/assets/solo-dancer.jpg';
import dancerGolden from '@/assets/dancer-golden.jpg';

const Classes = () => {
  const classPackages = [
    {
      title: "1 Month",
      duration: "1 hr",
      price: "₹1,000",
      image: groupDancers,
      features: ["Basic footwork", "Hand gestures", "Simple compositions", "Cultural introduction"]
    },
    {
      title: "3 MONTHS",
      duration: "1 hr", 
      price: "₹2,500",
      image: soloDancer,
      features: ["Intermediate techniques", "Complex rhythms", "Story expressions", "Performance preparation"],
      popular: true
    },
    {
      title: "1 YEAR",
      duration: "1 hr",
      price: "₹10,000", 
      image: dancerGolden,
      features: ["Advanced choreography", "Professional training", "Performance opportunities", "Certification"]
    }
  ];

  return (
    <section id="classes" className="py-20 bg-deep-brown">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-warm-cream mb-6">
            Our Classes
          </h2>
          <div className="w-24 h-1 bg-gradient-golden mx-auto rounded-full"></div>
          <Button className="mt-8 bg-royal-purple hover:bg-royal-purple/80 text-white rounded-full px-8">
            Reserve Your Spot
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {classPackages.map((pkg, index) => (
            <Card 
              key={index}
              className={`group hover:scale-105 transition-all duration-500 bg-card border-golden/20 relative overflow-hidden ${
                pkg.popular ? 'ring-2 ring-golden shadow-golden' : ''
              }`}
            >
              {pkg.popular && (
                <div className="absolute top-4 right-4 bg-gradient-golden text-deep-brown text-xs font-bold px-3 py-1 rounded-full">
                  POPULAR
                </div>
              )}
              
              <div className="h-48 overflow-hidden">
                <img 
                  src={pkg.image} 
                  alt={pkg.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>

              <CardHeader>
                <CardTitle className="text-2xl font-bold text-deep-brown mb-2">
                  {pkg.title}
                </CardTitle>
                <div className="flex items-center gap-4 text-muted-foreground">
                  <div className="flex items-center gap-1">
                    <Clock className="h-4 w-4" />
                    <span>{pkg.duration}</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <IndianRupee className="h-4 w-4" />
                    <span className="text-2xl font-bold text-golden">{pkg.price}</span>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                <ul className="space-y-2">
                  {pkg.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center gap-2 text-sm">
                      <div className="w-2 h-2 bg-golden rounded-full"></div>
                      {feature}
                    </li>
                  ))}
                </ul>
                
                <Button 
                  className="w-full bg-gradient-bronze hover:shadow-warm text-warm-cream transition-all duration-300"
                >
                  Join Now
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Classes;