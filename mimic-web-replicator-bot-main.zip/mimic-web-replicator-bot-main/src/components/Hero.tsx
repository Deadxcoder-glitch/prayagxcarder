import { Button } from '@/components/ui/button';
import heroImage from '@/assets/kathak-hero.jpg';

const Hero = () => {
  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-hero"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="animate-fade-in">
          <h1 className="text-5xl md:text-7xl font-bold text-warm-cream mb-6 tracking-wide">
            Kathak
          </h1>
          <p className="text-xl md:text-2xl text-golden mb-8 font-light tracking-wider">
            CLASSICAL INDIAN DANCE
          </p>
          <p className="text-lg md:text-xl text-warm-cream/90 mb-12 max-w-2xl mx-auto leading-relaxed">
            Embark on a transformative journey through the ancient art of Kathak, 
            where every movement tells a story and every gesture connects you to centuries of tradition.
          </p>
          
          <Button 
            size="lg"
            className="bg-gradient-golden hover:shadow-golden text-deep-brown font-semibold px-12 py-6 text-lg rounded-full transition-all duration-300 hover:scale-105"
          >
            Learn More
          </Button>
        </div>
      </div>

      {/* Decorative Wave at Bottom */}
      <div className="absolute bottom-0 left-0 right-0">
        <svg viewBox="0 0 1200 120" fill="none" className="w-full h-20">
          <path d="M0,120 L0,60 Q300,0 600,60 T1200,60 L1200,120 Z" fill="hsl(var(--warm-cream))" />
        </svg>
      </div>
    </section>
  );
};

export default Hero;