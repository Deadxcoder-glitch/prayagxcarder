import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Offerings from '@/components/Offerings';
import Classes from '@/components/Classes';
import Testimonials from '@/components/Testimonials';
import Contact from '@/components/Contact';

const Index = () => {
  return (
    <div className="min-h-screen">
      <Navbar />
      <Hero />
      <Offerings />
      <Classes />
      <Testimonials />
      <Contact />
    </div>
  );
};

export default Index;
